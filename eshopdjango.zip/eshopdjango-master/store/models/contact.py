from django.db import models


# Create your models here.
class Contacts(models.Model):
    name = models.CharField(max_length=150)
    email = models.CharField(max_length=150)
    phone = models.CharField(max_length=12)
    message = models.TextField()


    